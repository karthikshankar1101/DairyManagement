            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
<p>Developed By KARTHIK and DRUV</p>
                        </div>
                    </div>
                </footer>
            </div>